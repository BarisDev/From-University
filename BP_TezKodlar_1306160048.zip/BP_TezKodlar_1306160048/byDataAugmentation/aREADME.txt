#PROGRAM AKIŞI

byXMLParser -> XML'den dataları çeker ve ditch.pickle uzantılı dosyaya kaydeder. (.pkl ile aynı şey)
byDataAugmentation -> ditch.pickle uzantılı dosyadan xmin ymin xmax ymax name değerlerini okur. Yeni görselleri oluşturur, bu görselleri ve yeni xmin xmax ymin ymax name değerlerini augmented.pkl dosyasına kaydeder.
byXMLCreator -> XML dosyasını kopyalar, augmented.pkl dosyasından xmin ymin xmax ymax name değerlerini okur ve kopyalanan yeni XML'e kaydeder.

byTXTParser -> TXT'den dataları çeker ve değerleri YOLO TXT formatından PASCAL VOC XML formatına uyarlar, ditch.pickle dosyasına kaydeder. (.pkl ile aynı şey)
byDataAugmentation -> ditch.pickle uzantılı dosyadan xmin ymin xmax ymax name değerlerini okur. Yeni görselleri oluşturur, bu görselleri ve yeni xmin xmax ymin ymax name değerlerini augmented.pkl dosyasına kaydeder.
byTXTCreator -> augmented.pkl dosyasındaki değerleri PASCAL VOC XML formatından YOLO TXT formatına dönüştürerek yeni oluşturular TXT dosyalarına kaydeder.

byJSONParser -> JSON'dan dayaları çeker ve değerleri ditch.pickle uzantılı dosyaya kaydeder.(.pkl ile aynı şey)
byDataAugmentation -> ditch.pickle uzantılı dosyadan xmin ymin xmax ymax name değerlerini okur. Yeni görselleri oluşturur, bu görselleri ve yeni xmin xmax ymin ymax name değerlerini augmented.pkl dosyasına kaydeder.
byJSONCreator -> augmented.pkl dosyasındaki değerleri kullanarak yeni bir JSON dosyası oluşturur.


#KULLANIM
1-)Paketlerin kurulumunu yapın:
	pip install opencv-python
	pip install matplotlib

2-)images klasörüne görselinizi ve etiket dosyanızı atın.
(YOLO txt formatı için sadece etiket dosyasını atın, labelmap dosyasını atmayın)

3-)byController -> Değiştirmeniz gereken tek dosya budur, çalıştırdığınız zaman sistem size otomatik olarak generated_images klasörüne çıktıları atacak.
	count -> 1 görselden kaç tane augmented görsel elde edeceğinizi belirler.
	augment_type -> "json, xml, txt" değerlerinden birini alır. Hangi annotation için hangi augmentation yapılacağını belirler.
	label_groups -> Etiket kümesidir.

NOT: Test olması için images klasöründe araç kaput içi görseli ve her formattaki annotation dosyası bulunmaktadır. Dolayısıyla kendi projenizde sadece birini kullanmanız yeterlidir.