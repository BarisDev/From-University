#@author BarisDev
#@contact:
###mail: baris-yarar@hotmail.com
###twitter: @BarisDev
###instagram: bybarisyarar
###website: byarar.com
#@version 2.0

import cv2
import pickle as pkl
from byDataAugmentation import *

def byTXTCreator(filename,count):
    #img = "{}_{}.jpg".format(filename,count)
    #xmlpath = path+'\\'+img
    test_file = open("augmented.pkl","rb")
    test = pkl.load(test_file)

    img = cv2.imread("images/{}.jpg".format(filename))[:,:,::-1]
    image_width = img.shape[1]
    image_height = img.shape[0]
    #deletedCount = deleted_count()
    #print(deletedCount)
    #print(test)
    #print(len(test))

    ids = []
    new_x = []
    new_y = []
    w = []
    h = []

#<object-class> - integer number of object from 0 to (classes-1)
#<x> <y> <width> <height> - float values relative to width and height of image, it can be equal from (0.0 to 1.0]
#for example: <x> = <absolute_x> / <image_width> or <height> = <absolute_height> / <image_height>
#atention: <x> <y> - are center of rectangle (are not top-left corner)
    if len(test) != 0:
        new_txt = open("generated_images/{}_{}.txt".format(filename,count), "w")
        for countt in range(len(test)):
            ids.append(test[countt][4])
            #xml: xmin ymin xmax ymax
            new_x.append(float((test[countt][0] + test[countt][2])/2/image_width)) #x center
            new_y.append(float((test[countt][1] + test[countt][3])/2/image_height)) #y center
            w.append(float((test[countt][2] - test[countt][0])/image_width))    #width
            h.append(float((test[countt][3] - test[countt][1])/image_height))   #height   
            new_txt.write(str(ids[countt])+" "+str(new_x[countt])+" "+str(new_y[countt])+" "+str(w[countt])+" "+str(h[countt])+"\n")
            #print(new_x)
            #print(new_y)
            #print(w)
            #print(h)
        new_txt.close()
        print("txt file {}_{} created successfully..".format(filename,count))
    else:
        print("txt file {}_{} creation FAILED..".format(filename,count))
    