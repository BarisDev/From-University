import xml.etree.ElementTree as ET
from array import *
import pickle
from shutil import copyfile
import pickle as pkl

from numpy.lib.function_base import delete
from byDataAugmentation import *
import numpy as np

def byXMLCreator(filename,path,count,label_groups):
    tree = ET.parse("images/{}.xml".format(filename))
    root = tree.getroot()
    ximg = "{}_{}.jpg".format(filename,count) #filename for xml
    xmlpath = path+'\\'+ximg
    test_file = open("augmented.pkl","rb")
    test = pkl.load(test_file)
    #print("augmented.pkl: "+str(test))
    #print(test[0][4])
    
    print("BBOXTAN GELEN: "+str(deleted_box())) # True
    print("BBOXTAN GELEN 2: "+str(deleted_count())) # 2
    print("BBOXTAN GELEN 3: "+str(deleted_cords())) # 1
    
    
    switcher = {}
    for i in range(len(label_groups)):
        switcher[i] = label_groups[i]
    #print("switcher: "+str(switcher))

    deletedCount = deleted_count()
    if deleted_box():
        print("IF GIRDIM")
        
        temptext = []
        deletedCoords = deleted_cords()
        
        #print("IF GIRDIM2 : "+str(type(deletedCount)))

        for countt in range(deletedCount):
            temptext.append(str(switcher.get(deletedCoords[countt])))
        print(temptext)

        counter = 0
        
        for obj in root.findall("object"): #3 kere dönecek
            name = obj.find("./name")
            if name.text in temptext:
                root.remove(obj)
                print(str(name.text)+" adlı nesne silindi")

        #print("count ---------- "+str(count))
        #silinen objeyi yeni bir xml dosyası olarak kaydet ve yeni oluşturulan xml dosyasından verileri çek
        tree.write('temp_xml/{}_{}.xml'.format(filename,count))
        tree = ET.parse("temp_xml/{}_{}.xml".format(filename,count))
        root = tree.getroot()

        #print("test:::....................."+str(test))
        for nam in root.iter("name"):
            #print("iter name: ..............................................+ "+nam.text)
            real_temp = test[counter][4]
            nam.text = str(switcher.get(real_temp))
            counter = counter + 1
        counter = 0
        for xmin in root.iter("xmin"):
            xmin.text = str(test[counter][0])
            counter = counter + 1
        counter = 0
        for ymin in root.iter("ymin"):
            ymin.text = str(test[counter][1])
            counter = counter + 1   
        counter = 0
        for xmax in root.iter("xmax"):
            xmax.text = str(test[counter][2])
            counter = counter + 1   
        counter = 0
        for ymax in root.iter("ymax"):
            ymax.text = str(test[counter][3])
            counter = counter + 1
        for xfile in root.iter("filename"):
            xfile.text = ximg
        for xpath in root.iter("path"):
            xpath.text = xmlpath
    
        test_file.close()
        if len(label_groups) != deletedCount:
            tree.write('generated_images/{}_{}.xml'.format(filename,count))
            print("xml file {}_{} created successfully..".format(filename,count))
        else:
            print("xml file {}_{} creation FAILED..".format(filename,count))
    else:
        counter = len(test)
        print("ELSE GİRDİM")
        counter = 0
        for nam in root.iter("name"):
            #print("counter: "+str())
            print("test-counter: "+str(test[counter][4]))
            real_temp = test[counter][4]
            nam.text = str(switcher.get(real_temp))
            counter = counter + 1
        counter = 0
        for xmin in root.iter("xmin"):
            xmin.text = str(test[counter][0])
            counter = counter + 1
        counter = 0
        for ymin in root.iter("ymin"):
            ymin.text = str(test[counter][1])
            counter = counter + 1   
        counter = 0
        for xmax in root.iter("xmax"):
            xmax.text = str(test[counter][2])
            counter = counter + 1   
        counter = 0
        for ymax in root.iter("ymax"):
            ymax.text = str(test[counter][3])
            counter = counter + 1
        for xfile in root.iter("filename"):
            xfile.text = ximg
        for xpath in root.iter("path"):
            xpath.text = xmlpath
        test_file.close()
        tree.write('generated_images/{}_{}.xml'.format(filename,count))
        print("xml file {}_{} created successfully..".format(filename,count))