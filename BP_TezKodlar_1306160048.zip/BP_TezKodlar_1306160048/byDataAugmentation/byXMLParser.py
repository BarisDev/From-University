import xml.etree.ElementTree as ET
from array import *
import pickle

def byXMLParser(filename,label_groups):
    tree = ET.parse("images/{}.xml".format(filename))
    root = tree.getroot()
    xmin = []
    xmax = []
    ymin = []
    ymax = []
    name = []
    nums = []
    coord = []
    main = []
    switcher = {}
    for i in range(len(label_groups)):
        switcher[label_groups[i]] = i
    print("switcher: "+str(switcher))
    
    for objects in root.iter("object"):
        name.append(switcher.get(objects.find("name").text))
    print("name: "+str(name))

    for bndbox in root.iter("bndbox"):
        xmin.append(int(bndbox.find("xmin").text))
        xmax.append(int(bndbox.find("xmax").text))
        ymin.append(int(bndbox.find("ymin").text))
        ymax.append(int(bndbox.find("ymax").text))
    a = len(xmin)
    for x in range(a):
        nums.append(xmin[x])
        nums.append(ymin[x])
        nums.append(xmax[x])
        nums.append(ymax[x])
        nums.append(name[x])
    #print("byXMLParserNums: "+str(nums))
    
    #nums listesi verileri "xmin ymin xmax ymax name" sırasına sokmak için oluşturuldu
    #temp değişkeni nums'un her daim 5'in katları şeklinde eleman sayısına sahip olacağı için 5'e bölündü
    #buradaki amaç elemanları 5'er 5'er gruplayıp main listesine atmak
    temp = int(len(nums) / 5) #2
    #print(temp)
    for b in range(temp):   #0,1 
        for d in range(5): #0,5 5,10
            coord.append(nums[0])
            nums.pop(0)
        #print(coord)
        temp2 = coord.copy()
        main.insert(b,temp2)
        for q in range(5):
            coord.pop(0)
        #print(main)
        
    print("byXMLParserMain "+str(main))
    
    pickle_out = open("ditch.pickle","wb")
    pickle.dump(main,pickle_out)
    pickle_out.close()
    
###TEST YOUR PICKLE FILE BELOW HERE
    #pickle_tester = open("ditch.pickle","rb")
    #pickle_test = pickle.load(pickle_tester)
    #print("ditch.pickle: "+str(pickle_test))
    #pickle_tester.close()
