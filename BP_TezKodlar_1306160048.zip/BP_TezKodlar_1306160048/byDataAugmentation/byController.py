import byDataAugmentation
import byXMLCreator
import byXMLParser
import os
import byTXTCreator
import byTXTParser
import byJSONParser
import byJSONCreator
#####USER DEFINED VARIABLES
###count: how many images do you want?
###label_groups: your label groups (racoon, car, cat, dog, etc.)
###augment_type: xml yolo or json

count = 10
label_groups = ["motor","motor_sogutma_suyu","motor_yag_kapagi"]
augment_type = "txt"

path = os.path.dirname(os.path.abspath(__file__))
#print(path)
files = []
if(augment_type == "xml"):
    print("Augment Type: XML")
    for file in os.listdir(path+"\\images"):
        if file.endswith(".xml"):
            files.append(os.path.join(file))
    #print(files)

    for xmlfile in range(len(files)):
        filename = os.path.splitext(files[0])[0]
        imgname = filename+".jpg"
        #print(filename)
        byXMLParser.byXMLParser(filename,label_groups)
        for counts in range(count):
            byDataAugmentation.byDataAugmentation(filename,counts,len(label_groups))
            byXMLCreator.byXMLCreator(filename,path,counts,label_groups)
        files.pop(0)

if(augment_type == "json"):
    print("Augment Type: JSON")
    for file in os.listdir(path+"\\images"):
        if file.endswith(".json"):
            files.append(os.path.join(file))
    #print(files)

    for xmlfile in range(len(files)):
        filename = os.path.splitext(files[0])[0]
        imgname = filename+".jpg"
        #print(filename)
        byJSONParser.byJSONParser(filename,label_groups)
        for counts in range(count):
            byDataAugmentation.byDataAugmentation(filename,counts,len(label_groups))
            byJSONCreator.byJSONCreator(filename,path,counts,label_groups)
        files.pop(0)

if(augment_type == "txt"):
    print("Augment Type: txt")
    for file in os.listdir(path+"\\images"):
        if file.endswith(".txt"):
            files.append(os.path.join(file))
    #print(files)

    for xmlfile in range(len(files)):
        filename = os.path.splitext(files[0])[0]
        imgname = filename+".jpg"
        #print(filename)
        byTXTParser.byTXTParser(filename)
        for counts in range(count):
            byDataAugmentation.byDataAugmentation(filename,counts,len(label_groups))
            byTXTCreator.byTXTCreator(filename,counts)
        files.pop(0)
