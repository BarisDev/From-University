#@author BarisDev
#@contact:
###mail: baris-yarar@hotmail.com
###twitter: @BarisDev
###instagram: bybarisyarar
###website: byarar.com
#@version 3.0

import json
import pickle
def byJSONParser(filename,label_groups):
    jsonfile = open("images/{}.json".format(filename),"r")
    readable_json = json.load(jsonfile)
    #print(len(readable_json['shapes']))    #etiket sayısı
    #print(readable_json['shapes'][0]['points'])    #0. etiketin koordinatları
    xmin = []
    ymin = []
    xmax = []
    ymax = []
    name = []
    switcher = {}
    nums = []
    main = []
    coord = []
    
    for i in range(len(label_groups)):
        switcher[label_groups[i]] = i
    #print(switcher)
    for i in range(len(readable_json['shapes'])):
        #print(readable_json['shapes'][i]['points'][0][0])
        xmin.append(readable_json['shapes'][i]['points'][0][0])
        ymin.append(readable_json['shapes'][i]['points'][0][1])
        xmax.append(readable_json['shapes'][i]['points'][1][0])
        ymax.append(readable_json['shapes'][i]['points'][1][1])
        name.append(switcher.get(readable_json['shapes'][i]['label']))
    
    for j in range(len(xmin)):
        nums.append(xmin[j])
        nums.append(ymin[j])
        nums.append(xmax[j])
        nums.append(ymax[j])
        nums.append(name[j])

    #print(nums)

    temp = int(len(nums) / 5) #2
    for b in range(temp):   #0,1 
        for d in range(5): #0,5 5,10
            coord.append(nums[0])
            nums.pop(0)
        #print(coord)
        temp2 = coord.copy()
        main.insert(b,temp2)
        for q in range(5):
            coord.pop(0)
        
    print(main)    
    jsonfile.close()

    pickle_out = open("ditch.pickle","wb")
    pickle.dump(main,pickle_out)
    pickle_out.close()
    
###TEST YOUR PICKLE FILE BELOW HERE
    #pickle_tester = open("ditch.pickle","rb")
    #pickle_test = pickle.load(pickle_tester)
    #print("ditch.pickle: "+str(pickle_test))
    #pickle_tester.close()