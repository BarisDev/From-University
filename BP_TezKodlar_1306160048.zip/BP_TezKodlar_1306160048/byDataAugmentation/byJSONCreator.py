#@author BarisDev
#@contact:
###mail: baris-yarar@hotmail.com
###twitter: @BarisDev
###instagram: bybarisyarar
###website: byarar.com
#@version 3.0
import pickle as pkl
import json
from byDataAugmentation import *
def byJSONCreator(filename,path,count,label_groups):

    #Copy original json file to newly created augmented json file
    jsonfile = open("images/{}.json".format(filename),"r")
    readable_json = json.load(jsonfile)
    #print(readable_json)
    jimg = "{}_{}.jpg".format(filename,count) #filename for xml
    #jsonpath = path+'\\'+jimg
    #Read augmented coordinates and change json data
    test_file = open("augmented.pkl","rb")
    test = pkl.load(test_file)
    switcher = {}
    for i in range(len(label_groups)):
        switcher[i] = label_groups[i]
    #print(switcher)

    print("BBOXTAN GELEN: "+str(deleted_box())) # True
    #print("BBOXTAN GELEN 2: "+str(deleted_count())) # 2
    #print("BBOXTAN GELEN 3: "+str(deleted_cords())) # 1
    
    
    deletedCoords = deleted_cords()
    deletedCount = deleted_count()
    temptext = []

    if deleted_box():
        #silinenlerin dizisi
        for countt in range(deletedCount):
            temptext.append(str(switcher.get(deletedCoords[countt])))
        print(temptext)

    #label'ı motor yağ kapağı olan shapes'in elemanını bul
        size = len(readable_json['shapes'])
        j = 0
        while len(readable_json['shapes']) > 0 and j < len(readable_json['shapes']):
            
            if readable_json['shapes'][j]['label'] in temptext:
                del readable_json['shapes'][j]
            j = j + 1    
        #for k in readable_json
    #print("test: "+str(test))
    if len(test) != 0:
        for countt in range(len(test)):
            #print(len(test) - deletedCount) #augmented xmin
            readable_json['shapes'][countt]['label'] = switcher.get(test[countt][4])
            readable_json['shapes'][countt]['points'][0][0] = test[countt][0]
            readable_json['shapes'][countt]['points'][0][1] = test[countt][1]
            readable_json['shapes'][countt]['points'][1][0] = test[countt][2]
            readable_json['shapes'][countt]['points'][1][1] = test[countt][3]
        
        readable_json['imagePath'] = jimg
    
        new_jsonfile = open("generated_images/{}_{}.json".format(filename,count), "w")
        new_jsonfile.write(json.dumps(readable_json, indent=2))
        new_jsonfile.close()
        print("json file {}_{} created successfully..".format(filename,count))
    else:
        print("xml file {}_{} creation FAILED..".format(filename,count))