#@author BarisDev
#@contact:
###mail: baris-yarar@hotmail.com
###twitter: @BarisDev
###instagram: bybarisyarar
###website: byarar.com
#@version 2.0
import cv2
import pickle
def byTXTParser(filename):
    
    #image width and height needed to convert
    img = cv2.imread("images/{}.jpg".format(filename))[:,:,::-1]
    #print("img shape: "+str(img.shape[0]))
    #print("img shape 2: "+str(img.shape[1]))
    image_width = img.shape[1]
    image_height = img.shape[0]
    #print(image_width)
    
    object_id = []
    object_x = []
    object_y = []
    object_width = []
    object_height = []

    xmin = []
    xmax = []
    ymin = []
    ymax = []
    nums = []
    main = []
    coord = []

    txtfile = open("images/{}.txt".format(filename),"r")
    #print("txtfile data: "+txtfile.read())
    string = txtfile.readlines()
    #print("string: "+str(string))

    for counter in range(len(string)):
        temp_string = string[counter].rstrip("\n")
        #print("temp_string: "+temp_string)
        split_string = temp_string.split(" ")
        #print("split_string: "+str(split_string))
        object_id.append(split_string[0])
        object_x.append(split_string[1])
        object_y.append(split_string[2])
        object_width.append(split_string[3])
        object_height.append(split_string[4])

    for x in range(len(object_x)):
        #temp = ((float(object_x[x])*int(image_width)*2)-float(object_width[x]))/2
        temp = (2 * image_width * float(object_x[x]) - (float(object_width[x]) * image_width))/2
        xmin.append(int(temp))
        temp = image_width * float(object_width[x]) + xmin[x]
        xmax.append(int(temp))
        temp = (2 * image_height * float(object_y[x]) - (float(object_height[x]) * image_height))/2
        ymin.append(int(temp))
        temp = image_height * float(object_height[x]) + ymin[x]
        ymax.append(int(temp))
            
    for x in range(len(xmin)):
        nums.append(xmin[x])
        nums.append(ymin[x])
        nums.append(xmax[x])
        nums.append(ymax[x])
        nums.append(int(object_id[x]))
        
    temp = int(len(nums) / 5) #2
    for b in range(temp):   #0,1 
        for d in range(5): #0,5 5,10
            coord.append(nums[0])
            nums.pop(0)
        #print(coord)
        temp2 = coord.copy()
        main.insert(b,temp2)
        for q in range(5):
            coord.pop(0)
        #print(main)
    
    #print("nums: "+str(nums))
    #print("byTxtParserMain: "+str(main))
    
    txtfile.close()

    pickle_out = open("ditch.pickle","wb")
    pickle.dump(main,pickle_out)
    pickle_out.close()
    
###TEST YOUR PICKLE FILE BELOW HERE
    #pickle_tester = open("ditch.pickle","rb")
    #pickle_test = pickle.load(pickle_tester)
    #print("ditch.pickle: "+str(pickle_test))
    #pickle_tester.close()