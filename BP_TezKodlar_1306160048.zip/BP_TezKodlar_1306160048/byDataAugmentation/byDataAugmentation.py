import numpy as np
import cv2
import matplotlib.pyplot as plt
import sys
import os
import pickle as pkl
import random


def deleted_box():
    return deleted_box

def deleted_count():
    return deleted_count

def deleted_cords():
    return deleted_cords


def HorizontalFlip(img, bboxes):
    img_center = np.array(img.shape[:2])[::-1]/2
    img_center = np.hstack((img_center, img_center))

    img = img[:, ::-1, :] #first flip image around x axis
    bboxes[:, [0, 2]] = bboxes[:, [0, 2]] + 2*(img_center[[0, 2]] - bboxes[:, [0, 2]])

    box_w = abs(bboxes[:, 0] - bboxes[:, 2])

    bboxes[:, 0] = bboxes[:, 0] - box_w
    bboxes[:, 2] = bboxes[:, 2] + box_w

    return img, bboxes


def drawRect(im, cords, color = None):

    im = im.copy()
    #print("before slice: "+str(cords))
    cords = cords[:,:4] #take xmin ymin xmax ymax values, we don't need the name parameter
    #print("after slice"+str(cords))
    cords = cords.reshape(-1,4)

    if not color:
        color = [255,255,255]
    for cord in cords:
        pt1, pt2 = (cord[0], cord[1]) , (cord[2], cord[3])
        pt1 = int(pt1[0]), int(pt1[1])
        pt2 = int(pt2[0]), int(pt2[1])
        im = cv2.rectangle(im.copy(), pt1, pt2, color, int(max(im.shape[:2])/200))
    return im


def getCorners(bboxes):
    #We need all coordinates of a bbox for calculating center point. We'll use center points at Rotation Matrix
    #x1,y1,x2,y2,x3,y3,x4,y4
    #sol üst x1,y1  sağ üst x2,y2 sol alt x3,y3 sağ alt x4,y4
    

    bbwidth = (bboxes[:,2] - bboxes[:,0]).reshape(-1,1) #x2-x1
    bbheight = (bboxes[:,3] - bboxes[:,1]).reshape(-1,1) #y2-y1
    
    x1 = bboxes[:,0].reshape(-1,1)
    y1 = bboxes[:,1].reshape(-1,1)
    
    x2 = x1 + bbwidth
    y2 = y1 
    
    x3 = x1
    y3 = y1 + bbheight
    
    x4 = bboxes[:,2].reshape(-1,1)
    y4 = bboxes[:,3].reshape(-1,1)
    
    corners = np.hstack((x1,y1,x2,y2,x3,y3,x4,y4))
    return corners

def rotateImage(image, angle):

    # cx cy center of image
    (h, w) = image.shape[:2]
    (cx, cy) = (w // 2, h // 2)

    M = cv2.getRotationMatrix2D((cx, cy), angle, 1.0)
    cos = np.abs(M[0, 0])
    sin = np.abs(M[0, 1])

    # new width and new height after rotation
    nW = int((h * sin) + (w * cos))
    nH = int((h * cos) + (w * sin))

    # rotation matrix with new widh and new height
    M[0, 2] += (nW / 2) - cx
    M[1, 2] += (nH / 2) - cy

    image = cv2.warpAffine(image, M, (nW, nH))

    #image = cv2.resize(image, (w,h))
    return image

def rotateBox(corners, angle,  cx, cy, h, w):

    corners = corners.reshape(-1,2)
    corners = np.hstack((corners, np.ones((corners.shape[0],1), dtype = type(corners[0][0]))))
    
    M = cv2.getRotationMatrix2D((cx, cy), angle, 1.0)
    
    cos = np.abs(M[0, 0])
    sin = np.abs(M[0, 1])
    
    nW = int((h * sin) + (w * cos))
    nH = int((h * cos) + (w * sin))

    M[0, 2] += (nW / 2) - cx
    M[1, 2] += (nH / 2) - cy
    
    calculated = np.dot(M,corners.T).T
    calculated = calculated.reshape(-1,8)
    return calculated


def newBoundingBox(corners):
    xarr = corners[:,[0,2,4,6]]
    yarr = corners[:,[1,3,5,7]]
    
    xmin = np.min(xarr,1).reshape(-1,1)
    ymin = np.min(yarr,1).reshape(-1,1)
    xmax = np.max(xarr,1).reshape(-1,1)
    ymax = np.max(yarr,1).reshape(-1,1)
    
    final = np.hstack((xmin, ymin, xmax, ymax,corners[:,8:]))
    
    return final


def Rotate(img,angle,bboxes):

    w,h = img.shape[1], img.shape[0]
    xcenter, ycenter = w//2, h//2

    corners = getCorners(bboxes)
    corners = np.hstack((corners, bboxes[:,4:]))

    img = rotateImage(img, angle)

    corners[:,:8] = rotateBox(corners[:,:8], angle, xcenter, ycenter, h, w)
    new_bbox = newBoundingBox(corners)

    scale_factor_x = img.shape[1] / w
    scale_factor_y = img.shape[0] / h

    img = cv2.resize(img, (w,h))
    new_bbox[:,:4] = new_bbox[:,:4] / [scale_factor_x, scale_factor_y, scale_factor_x, scale_factor_y]

    bboxes  = new_bbox
    bboxes = deleteBox(bboxes, [0,0,w, h], 0.5)
    return img, bboxes


#scale_x, scale_y are between -1 and +1
def Scale(img, scale_x, scale_y, bboxes):
    
    img_shape = img.shape
    
    resize_scale_x = 1 + scale_x
    resize_scale_y = 1 + scale_y
    
    img=  cv2.resize(img, None, fx = resize_scale_x, fy = resize_scale_y)
    #print("scale bboxes: "+str(bboxes))
    bboxes[:,:4] = bboxes[:,:4] * [resize_scale_x, resize_scale_y, resize_scale_x, resize_scale_y]
    
    canvas = np.zeros(img_shape, dtype = np.uint8)
    
    y_lim = int(min(resize_scale_y,1)*img_shape[0])
    x_lim = int(min(resize_scale_x,1)*img_shape[1])
    
    canvas[:y_lim,:x_lim,:] =  img[:y_lim,:x_lim,:]
    img = canvas
    bboxes = deleteBox(bboxes, [0,0,1 + img_shape[1], img_shape[0]], 0.5)
    return img, bboxes
    
def bboxArea(bbox):
    return (bbox[:,3] - bbox[:,1])*(bbox[:,2] - bbox[:,0])

def deleteBox(bbox, deleteBox, alpha):

    global deleted_box
    global deleted_count
    global deleted_cords

    arr = (bboxArea(bbox))

    xmin = np.maximum(bbox[:,0], deleteBox[0]).reshape(-1,1)
    ymin = np.maximum(bbox[:,1], deleteBox[1]).reshape(-1,1)
    xmax = np.minimum(bbox[:,2], deleteBox[2]).reshape(-1,1)
    ymax = np.minimum(bbox[:,3], deleteBox[3]).reshape(-1,1)

    bbox = np.hstack((xmin, ymin, xmax, ymax, bbox[:,4:]))
    #delta_area: change of bbox area
    delta_area = ((arr - bboxArea(bbox))/arr)
    mask = (delta_area < (1 - alpha)).astype(int)
    #print("DELETE: MASK LEN: "+str(mask))
    #print("DELETE: DELTA AREA: "+str(delta_area))
    #print("DELETE: ALFA: "+str(alpha))
    for counter in range(len(mask)):
        if(mask[counter] == 0):
            #print("MASK COUNTER: "+str(mask[counter]))
            deleted_box = True
            deleted_count = deleted_count + 1
            deleted_cords.append(bbox[counter][4])

    bbox = bbox[mask == 1,:]
    return bbox


def Translate(img, translate_x, translate_y, bboxes):
    img_shape = img.shape
    
    translate_factor_x = translate_x
    translate_factor_y = translate_y
       
    canvas = np.zeros(img_shape).astype(np.uint8)

    #get the top-left corner co-ordinates of the shifted box 
    corner_x = int(translate_factor_x*img.shape[1])
    corner_y = int(translate_factor_y*img.shape[0])
    
    #change the origin to the top-left corner of the translated box
    orig_box_cords =  [max(0,corner_y), max(corner_x,0), min(img_shape[0], corner_y + img.shape[0]), min(img_shape[1],corner_x + img.shape[1])]

    mask = img[max(-corner_y, 0):min(img.shape[0], -corner_y + img_shape[0]), max(-corner_x, 0):min(img.shape[1], -corner_x + img_shape[1]),:]

    canvas[orig_box_cords[0]:orig_box_cords[2], orig_box_cords[1]:orig_box_cords[3],:] = mask
    img = canvas
    
    bboxes[:,:4] = bboxes[:,:4] + [corner_x, corner_y, corner_x, corner_y]
    bboxes = deleteBox(bboxes, [0,0,img_shape[1], img_shape[0]], 0.5)
    
    return img, bboxes


def RandomHSV(img, bboxes):
    # ilk hali
    # hue satürasyon parlaklık girilen değerin + - aralığından random seçilir    
    #hue = random.randint(-hue,hue)
    #saturation = random.randint(-saturation, saturation)
    #brightness = random.randint(-brightness, brightness)
    
    #son hali: herşeyi random al
    hue, saturation, brightness = random.randint(0,180), random.randint(0,180), random.randint(0,180) #0 180 arası hue saturation brightness

    img = img.astype(int)
    
    a = np.array([hue, saturation, brightness]).astype(int)
    img = img + np.reshape(a, (1,1,3))
    
    img = np.clip(img, 0, 255)
    img[:,:,0] = np.clip(img[:,:,0],0, 179)
    
    img = img.astype(np.uint8)

    #xml dosyasında karışıklık olmasın diye değer atamask için çağırıldı, bir işlevi yok
    img_shape = img.shape
    deleteBox(bboxes, [0,0,img_shape[1], img_shape[0]], 0.5)
    
    return img, bboxes

def RandomHorizontalFlip(img, bboxes):
    img_center = np.array(img.shape[:2])[::-1]/2
    img_center = np.hstack((img_center, img_center))
    if random.random() < 0.5: #%50 ihtimalle döndürülecek
        img = img[:, ::-1, :] #first flip image around x axis
        bboxes[:, [0, 2]] = bboxes[:, [0, 2]] + 2*(img_center[[0, 2]] - bboxes[:, [0, 2]])

        box_w = abs(bboxes[:, 0] - bboxes[:, 2])

        bboxes[:, 0] = bboxes[:, 0] - box_w
        bboxes[:, 2] = bboxes[:, 2] + box_w

    #xml dosyasında karışıklık olmasın diye değer atamask için çağırıldı, bir işlevi yok
    img_shape = img.shape
    deleteBox(bboxes, [0,0,img_shape[1], img_shape[0]], 0.5)

    return img, bboxes

def RandomScale(img, bboxes):
    img_shape = img.shape
    
    scale = random.uniform(0,1)
    resize_scale_x = 1 + scale
    resize_scale_y = 1 + scale
    
    img=  cv2.resize(img, None, fx = resize_scale_x, fy = resize_scale_y)
    #print("scale bboxes: "+str(bboxes))
    bboxes[:,:4] = bboxes[:,:4] * [resize_scale_x, resize_scale_y, resize_scale_x, resize_scale_y]
    
    canvas = np.zeros(img_shape, dtype = np.uint8)
    
    y_lim = int(min(resize_scale_y,1)*img_shape[0])
    x_lim = int(min(resize_scale_x,1)*img_shape[1])
    
    canvas[:y_lim,:x_lim,:] =  img[:y_lim,:x_lim,:]
    img = canvas
    bboxes = deleteBox(bboxes, [0,0,1 + img_shape[1], img_shape[0]], 0.5)
    return img, bboxes

def RandomTranslate(img, bboxes):
    img_shape = img.shape
    
    translate = 0.5 #random.uniform(0,0.5)

    #0 translate yapma, 1 x'te translate, 2 y'de translate, 3 hem x hem y'de translate
    axis = random.randint(0, 3)
    if axis == 0:
        translate_factor_x = 0
        translate_factor_y = 0
    if axis == 1:
        translate_factor_x = random.choice((-translate, translate))
        translate_factor_y = 0
    if axis == 2:
        translate_factor_x = 0
        translate_factor_y = random.choice((-translate, translate))
    if axis == 3:
        translate_factor_x = random.choice((-translate, translate))
        translate_factor_y = random.choice((-translate, translate))
    

    canvas = np.zeros(img_shape).astype(np.uint8)

    #get the top-left corner co-ordinates of the shifted box 
    corner_x = int(translate_factor_x*img.shape[1])
    corner_y = int(translate_factor_y*img.shape[0])
    
    #change the origin to the top-left corner of the translated box
    orig_box_cords =  [max(0,corner_y), max(corner_x,0), min(img_shape[0], corner_y + img.shape[0]), min(img_shape[1],corner_x + img.shape[1])]

    mask = img[max(-corner_y, 0):min(img.shape[0], -corner_y + img_shape[0]), max(-corner_x, 0):min(img.shape[1], -corner_x + img_shape[1]),:]

    canvas[orig_box_cords[0]:orig_box_cords[2], orig_box_cords[1]:orig_box_cords[3],:] = mask
    img = canvas
    
    bboxes[:,:4] = bboxes[:,:4] + [corner_x, corner_y, corner_x, corner_y]
    bboxes = deleteBox(bboxes, [0,0,img_shape[1], img_shape[0]], 0.5)
    
    return img, bboxes

def RandomRotate(img, bboxes):
    w,h = img.shape[1], img.shape[0]
    xcenter, ycenter = w//2, h//2
    
    corners = getCorners(bboxes)
    corners = np.hstack((corners, bboxes[:,4:]))

    angle = random.randint(0, 360)

    img = rotateImage(img, angle)

    corners[:,:8] = rotateBox(corners[:,:8], angle, xcenter, ycenter, h, w)
    new_bbox = newBoundingBox(corners)

    scale_factor_x = img.shape[1] / w
    scale_factor_y = img.shape[0] / h

    img = cv2.resize(img, (w,h))
    new_bbox[:,:4] = new_bbox[:,:4] / [scale_factor_x, scale_factor_y, scale_factor_x, scale_factor_y]

    bboxes  = new_bbox
    bboxes = deleteBox(bboxes, [0,0,w, h], 0.5)
    return img, bboxes

def Shear(img, shear_factor, bboxes):

    w,h = img.shape[1], img.shape[0]
    if shear_factor < 0:
        img, bboxes = HorizontalFlip(img, bboxes)

    M = np.array([[1, abs(shear_factor), 0],[0,1,0]]) 

    #x, y -> x + alpha*y, y
    newWidth =  img.shape[1] + abs(shear_factor*img.shape[0])
    bboxes[:,[0,2]] = bboxes[:,[0,2]] + ((bboxes[:,[1,3]]) * abs(shear_factor) ).astype(int) 
    img = cv2.warpAffine(img, M, (int(newWidth), img.shape[0]))

    if shear_factor < 0:
    	img, bboxes = HorizontalFlip(img, bboxes)

    img = cv2.resize(img, (w,h))
    scale_factor_x = newWidth / w
    bboxes[:,:4] = bboxes[:,:4] / [scale_factor_x, 1, scale_factor_x, 1] 

    #xml dosyasında karışıklık olmasın diye değer atamask için çağırıldı, bir işlevi yok
    img_shape = img.shape
    deleteBox(bboxes, [0,0,img_shape[1], img_shape[0]], 0.5)


    return img, bboxes


def RandomShear(img, bboxes):

    w,h = img.shape[1], img.shape[0]

    shear_factor = random.uniform(-0.5, 0.5) #float

    if shear_factor < 0:
        img, bboxes = HorizontalFlip(img, bboxes)

    M = np.array([[1, abs(shear_factor), 0],[0,1,0]]) 

    #x, y -> x + alpha*y, y
    newWidth =  img.shape[1] + abs(shear_factor*img.shape[0])
    bboxes[:,[0,2]] = bboxes[:,[0,2]] + ((bboxes[:,[1,3]]) * abs(shear_factor) ).astype(int) 
    img = cv2.warpAffine(img, M, (int(newWidth), img.shape[0]))

    if shear_factor < 0:
    	img, bboxes = HorizontalFlip(img, bboxes)

    img = cv2.resize(img, (w,h))
    scale_factor_x = newWidth / w
    bboxes[:,:4] = bboxes[:,:4] / [scale_factor_x, 1, scale_factor_x, 1] 

    #xml dosyasında karışıklık olmasın diye değer atamask için çağırıldı, bir işlevi yok
    img_shape = img.shape
    deleteBox(bboxes, [0,0,img_shape[1], img_shape[0]], 0.5)
    
    return img, bboxes


def byDataAugmentation(filename,count,labelamount):
    global deleted_box
    global deleted_count
    global deleted_cords

    deleted_box = False
    deleted_count = 0
    deleted_cords = []

    bboxes = []
    img = cv2.imread("images/{}.jpg".format(filename)) #[:,:,::-1]   #opencv loads images in bgr. the [:,:,::-1] does bgr -> rgb
    bboxes = pkl.load(open("ditch.pickle", "rb"))

    #inspect the bounding boxes
    #print("ditch.pickle---------: "+str(bboxes))
    bboxes = np.array(bboxes)    

    #print("after nparray: "+str(bboxes))

    #plotted_img = drawRect(img, bboxes)
    #plt.imshow(plotted_img)
    #plt.show()

    img_, bboxes_ = Rotate(img.copy(), -45, bboxes.copy())
    #img_, bboxes_ = Scale(img.copy(), 0.5, 0.5, bboxes.copy())
    #img_, bboxes_ = Translate(img.copy(), 0.2, 0.2, bboxes.copy())
    
    #img_, bboxes_ = RandomHSV(img.copy(), bboxes.copy())
    #img_, bboxes_ = RandomHorizontalFlip(img.copy(), bboxes.copy())
    #img_, bboxes_ = RandomScale(img.copy(), bboxes.copy())
    #img_, bboxes_ = RandomTranslate(img.copy(), bboxes.copy())
    #img_, bboxes_ = RandomRotate(img.copy(), bboxes.copy())

    #img_, bboxes_ = Shear(img.copy(), 0.5, bboxes.copy())
    #img_, bboxes_ = RandomShear(img.copy(), bboxes.copy())


    ##RANDOM DEĞERLERLE FONKSİYON ÇAĞIRMA
    
    #img_, bboxes_ = img.copy(), bboxes.copy()

    probability = random.random() #0 ile 1 arasında bir değer
    if probability > 0.5:
        img_, bboxes_ = RandomHorizontalFlip(img_, bboxes_)

    probability = random.random()
    if probability > 0.5:
        img_, bboxes_ = RandomRotate(img_, bboxes_) #angle randomrotate içinde 0 360 arası belirleniyor

    probability = random.random()
    if probability > 0.5:
        img_, bboxes_ = RandomScale(img_, bboxes_)

    probability = random.random()
    if probability > 0.5:
        img_, bboxes_ = RandomTranslate(img_, bboxes_)


    probability = random.random()
    if probability > 0.5:
        img_, bboxes_ = RandomShear(img_, bboxes_)

    probability = random.random()
    if probability > 0.5:
        img_, bboxes_ = RandomHSV(img_, bboxes_)



    plotted_img = drawRect(img_, bboxes_)
    #plt.imshow(plotted_img)
    #plt.show()

    if labelamount != deleted_count:
        cv2.imwrite("generated_images/{}_{}.jpg".format(filename,count),img_)
        cv2.imwrite("generated_boxes/{}_{}.jpg".format(filename,count),plotted_img)
    else:
        print("We lost all of the bboxes! No image created!")
    #print("bboxes_: "+str(bboxes_))
    file = open("augmented.pkl","wb")
    pkl.dump(bboxes_,file)
    file.close()
        
    #####TEST PICKLE FILE
    #testdataopen = open("augmented.pkl","rb")
    #testdata = pkl.load(testdataopen)
    #print("dataAugment:"+str(testdata))
    #testdataopen.close()
